import './App.css';
import MouseColor from './components/MouseColor';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <MouseColor />
      </header>
    </div>
  );
}

export default App;
